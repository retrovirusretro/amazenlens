# CLAUDE.md — AmazenLens AI Asistan Rehberi

Bu dosyayı her oturumun başında oku. Tüm kararlar burada.

---

## 🎯 Proje Özeti

**AmazenLens** — Amazon satıcıları için global araştırma SaaS platformu.
Helium 10 + Jungle Scout + AMZScout + SmartScout'un en iyi özelliklerini tek platformda birleştiriyor.
Türk kullanıcıya özel: Trendyol arbitrajı + Alibaba entegrasyonu + Türkçe arayüz.

**Hedef:** Global SaaS, yatırım alabilir ölçekte, $100K–$500K seed round hedefi.
**GitHub:** https://github.com/retrovirusretro/amazenlens

---

## 🛠️ Tech Stack (Kesin Kararlar)

| Katman | Teknoloji | Notlar |
|--------|-----------|--------|
| Backend | Python 3.11 + FastAPI | Python 3.13/3.14 pydantic-core sorunu var! |
| Frontend | React + Vite | localhost:5173 |
| Veritabanı | Supabase (PostgreSQL) | mnpwuaupqkkgdoryfqlr |
| Auth | Supabase Auth | Email doğrulama KAPALI (dev) |
| Ödeme | Stripe | Henüz entegre edilmedi |
| Amazon Verisi | Easyparser API | Şu an mock modda (kredi doldu) |
| Yedek API | Canopy API | 100 istek/ay ücretsiz |
| Fiyat Geçmişi | Keepa API | $20/ay — alınacak, BSR+satıcı+FBA verisi |
| Multi-market | Algopix API | Faz 2 |
| AI | Claude API (Anthropic) | Love/Hate analizi, niş skoru yorumu |
| Hosting FE | Vercel | Henüz deploy edilmedi |
| Hosting BE | Railway | ~$5/ay, henüz deploy edilmedi |
| Dil Desteği | i18next | TR / EN / DE / FR — Faz 1 bekliyor |

---

## 📁 Mevcut Proje Yapısı

```
C:\Users\Gökhan Ustaosmanoğlu\amazenlens\
├── CLAUDE.md                     ← Bu dosya
├── docs/
│   ├── spec.md                   ← Tüm özellikler ve fazlar
│   └── guclendiirme_arastirmasi.md ← Rakip analizi + güçlendirme fikirleri
├── backend/
│   ├── main.py
│   ├── requirements.txt
│   ├── .env                      ← GitHub'a yüklenmiyor! ✅
│   ├── database/supabase.py
│   ├── middleware/auth.py
│   ├── routers/
│   │   ├── amazon.py
│   │   ├── auth.py
│   │   ├── sourcing.py
│   │   ├── bulk.py
│   │   ├── blog.py
│   │   └── reviews.py            ← Love/Hate analizi
│   └── services/
│       ├── easyparser.py         ← Şu an mock modda
│       ├── niche_calculator.py   ← Unmet Demand + Red Flags + 3 Prong
│       ├── review_analyzer.py    ← Claude API, 4 dil
│       ├── alibaba.py
│       ├── global_arbitrage.py
│       └── bulk_import.py
└── frontend/
    └── src/
        ├── App.jsx
        ├── lib/api.js             ← API_URL = 'http://127.0.0.1:8000'
        ├── components/
        │   └── Layout.jsx         ← Koyu sidebar, Inter font, yeni tasarım
        └── pages/
            ├── AuthPage.jsx
            ├── Dashboard.jsx      ← Yeni tasarım ✅
            ├── SearchPage.jsx     ← Est.Revenue, FBA/FBM, satıcı, filtre ✅
            ├── ProductPage.jsx    ← Love/Hate, Unmet Demand, varyantlar ✅
            ├── UnavailablePage.jsx ← 3 sekme: ASIN/Keyword/Kategori ✅
            ├── NichePage.jsx
            ├── SourcingPage.jsx
            ├── BulkPage.jsx
            ├── BlogPage.jsx
            ├── BlogPostPage.jsx
            └── BlogAdminPage.jsx
```

---

## 🚀 Backend Başlatma

```powershell
cd "C:\Users\Gökhan Ustaosmanoğlu\amazenlens\backend"
venv\Scripts\activate
py main.py
# veya
py -m uvicorn main:app --host 127.0.0.1 --port 8000 --reload
```

⚠️ **ÖNEMLİ:** Edge tarayıcı kurumsal proxy localhost'u engelliyor!
- Backend: http://127.0.0.1:8000 (localhost değil!)
- Frontend: http://localhost:5173
- Swagger: http://127.0.0.1:8000/docs

## 🖥️ Frontend Başlatma

```powershell
cd "C:\Users\Gökhan Ustaosmanoğlu\amazenlens\frontend"
npm run dev
```

---

## 🔑 API Key Durumu (.env)

```env
SUPABASE_URL=https://mnpwuaupqkkgdoryfqlr.supabase.co  ✅
SUPABASE_ANON_KEY=eyJ...                                ✅
SUPABASE_SERVICE_KEY=eyJ...                             ✅
ANTHROPIC_API_KEY=sk-ant-...                            ✅
EASYPARSER_API_KEY=602a3292-...                         ✅ (mock modda)

STRIPE_SECRET_KEY=                                      ❌ Henüz yok
STRIPE_WEBHOOK_SECRET=                                  ❌ Henüz yok
KEEPA_API_KEY=                                          ❌ Alınacak ($20/ay)
ALIBABA_APP_KEY=                                        ❌ Mock data
EBAY_APP_ID=                                            ❌ Mock data
```

---

## 💰 Fiyatlandırma Planları

| Plan | Fiyat | Hedef |
|------|-------|-------|
| Free | $0 | 5 arama/gün — deneme |
| Starter | $19/ay | Bireysel Türk satıcı |
| Pro | $49/ay | Ciddi satıcı |
| Agency | $99/ay | Ajans / büyük satıcı |

---

## 📊 Mevcut Durum — FAZ TAKIBI

### ✅ FAZ 1 — TAMAMLANANLAR

| # | Özellik | Notlar |
|---|---------|--------|
| 1 | Kullanıcı kaydı/girişi | Supabase Auth |
| 2 | Keyword araması + görseller | Mock modda |
| 3 | Ürün detayı + platform linkleri | Varyantlar, FBA/FBM, satıcı sayısı |
| 4 | Unavailable Scanner | 3 sekme: ASIN/Keyword/Kategori |
| 5 | Niş Skoru (100pt) | Unmet Demand + Red Flags + 3 Prong |
| 6 | Alibaba Tedarikçi Finder | Mock data |
| 7 | Global Arbitraj | Trendyol/eBay, mock data |
| 8 | Toplu ASIN Import | CSV/Excel, 100 ASIN |
| 9 | Blog Sistemi | Admin panel + Supabase |
| 10 | Love/Hate Yorum Analizi | Claude API, 4 dil |
| 11 | Keywords on Fire | Est. Revenue kolonu |
| 12 | Cache sistemi | 1 saat TTL, kredi tasarrufu |
| 13 | Yeni UI Tasarımı | Inter font, koyu sidebar, Apple tarzı |

### ❌ FAZ 1 — BEKLEYENLER

| # | Özellik | Not |
|---|---------|-----|
| 14 | Stripe Ödeme + Pricing sayfası | Sıradaki büyük adım |
| 15 | Keepa API entegrasyonu | $20/ay, BSR+FBA+satıcı gerçek veri |
| 16 | 4 Dil Desteği (i18next) | Altyapı hazır, çeviri bekliyor |
| 17 | Quick Picks / Günün Fırsatları | Dashboard widget |
| 18 | NichePage yeni tasarım | Bekliyor |
| 19 | SourcingPage yeni tasarım | Bekliyor |
| 20 | AuthPage yeni tasarım | Bekliyor |
| 21 | BulkPage yeni tasarım | Bekliyor |
| 22 | Canlıya çık (Vercel + Railway) | Stripe sonrası |

### 🟡 FAZ 2 — PLANLANANLAR

| # | Özellik | İlham |
|---|---------|-------|
| 1 | Chrome & Edge Eklentisi | Jungle Scout |
| 2 | AI Listing Optimizer | Helium 10 |
| 3 | Review Analyzer — Gelişmiş | Keyword bazlı, rakiplerde yok |
| 4 | Keyword Explorer | Helium 10 Cerebro |
| 5 | Reverse ASIN | Helium 10 |
| 6 | Always Be Scanning | Tactical Arbitrage |
| 7 | Wholesale Manifest Upload | Tactical Arbitrage |
| 8 | WhatsApp/Telegram Alertleri | — |
| 9 | Sales Estimator | Jungle Scout |
| 10 | FBA Kar Hesaplayıcı | — |
| 11 | SnapSearch (görsel arama) | Google Lens |
| 12 | Business Valuation Tool | ZonGuru (zayıf var, biz güçlü yapacağız) |
| 13 | Sezonluk Talep + Stok Önerisi | Rakiplerde yok! |
| 14 | Product Opportunity Gap | Amazon POE + Niş Skoru entegrasyonu |
| 15 | Euro Flips | Amazon.de/fr/co.uk arası arbitraj |
| 16 | Listing Quality Score | AMZScout |
| 17 | Çok Kaynaklı Tedarikçi Karşılaştırma | Alibaba+DHgate+TR+KR yan yana |
| 18 | Kore Tedarikçileri (tradeKorea, EC21) | — |
| 19 | Global Sources, 1688.com | — |
| 20 | Vergi Araçları Modülü | VAT, Sales Tax, Gümrük hesabı |
| 21 | Hepsiburada arbitraj | — |

### 🟠 FAZ 3 — MOBİL & GELİŞMİŞ

| # | Özellik |
|---|---------|
| 1 | iOS + Android App (React Native) |
| 2 | Barkod Okuyucu |
| 3 | Seller Map |
| 4 | 1688 + Made-in-China + DHgate entegrasyonu |
| 5 | Türk Tedarikçi Veritabanı (KobiVadisi, Bilvio, Kolay İhracat) |
| 6 | Pan-European FBA rehberi |
| 7 | ABD Tedarikçi (ThomasNet) |
| 8 | Avrupa Tedarikçi (Europages) |
| 9 | Japonya pazarı özellikleri |
| 10 | Kore pazarı özellikleri |
| 11 | UAE/Suudi pazarı özellikleri |

### 🔵 FAZ 4 — ENTERPRİSE

| # | Özellik |
|---|---------|
| 1 | Intelligence API |
| 2 | ML Model Eğitimi |
| 3 | EtsyLens |
| 4 | Sesli Asistan |
| 5 | White-label B2B |
| 6 | Patent Risk Tarayıcı |
| 7 | SWOT Analizi (AI) |
| 8 | QuickBooks entegrasyonu |
| 9 | Meksika, Brezilya, Güney Afrika pazarları |

---

## 🏆 Rakip Farklılaştırıcılar

| Özellik | AmazenLens | Helium 10 | Jungle Scout | AMZScout |
|---------|------------|-----------|--------------|----------|
| Trendyol Arbitraj | ✅ | ❌ | ❌ | ❌ |
| Türkçe Arayüz | ✅ | ❌ | ❌ | ❌ |
| Niş Skoru (4 boyut) | ✅ 100pt | Sınırlı | Orta | 7/10 |
| Unmet Demand Tespiti | ✅ | ❌ | ❌ | ❌ |
| Love/Hate Yorum Analizi | ✅ Claude AI | Zayıf | Zayıf | Zayıf |
| Product Opportunity Gap | ✅ (Faz 2) | ❌ | ❌ | ❌ |
| Business Valuation | ✅ (Faz 2) | ❌ | ❌ | Zayıf |
| Fiyat başlangıç | $19/ay | $97/ay | $49/ay | $49/ay |
| Türk Tedarikçi DB | ✅ (Faz 3) | ❌ | ❌ | ❌ |
| Global Arbitraj | ✅ | ❌ | ❌ | ❌ |

---

## 🗺️ Yatırım Hedefleri

- TÜBİTAK BiGG: 900K TL (iş planı hazırlandı ✅)
- KOSGEB: 375K TL
- EIC Accelerator: €2.5M
- Y Combinator: $500K

---

## ⚠️ Önemli Kodlama Kuralları

1. `.env` dosyası asla GitHub'a yüklenmesin ✅ (gitignore'da)
2. API key'ler sadece backend'de, frontend'de asla
3. Python 3.11 kullan — 3.13/3.14 pydantic-core sorunu!
4. Alibaba/eBay API key yoksa mock data döndür
5. Backend her zaman 127.0.0.1:8000 (localhost değil — Edge proxy)
6. Venv: backend/venv klasöründe (.venv veya .venv-1 değil!)
7. Easyparser şu an mock modda — Keepa gelince gerçek veriye geç
8. Cache sistemi aktif — aynı ASIN 1 saat boyunca API'ye gitmiyor

---

## 🔄 Bu Dosyayı Ne Zaman Güncelle

- Yeni özellik tamamlandığında
- Faz geçişlerinde
- Tech stack değiştiğinde
- API key eklendiğinde
- Her oturum sonunda "CLAUDE.md'i güncelle" dersen Claude güncelleyecek
