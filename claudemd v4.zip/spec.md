# AmazenLens — Ürün Spesifikasyonu (spec.md)

**Versiyon:** 3.0  
**Son güncelleme:** Mart 2026  
**Durum:** Faz 1 büyük ölçüde tamamlandı, Faz 2 planlanıyor

---

## 1. Vizyon

Amazon satıcıları için tek platformda her şeyi sunan global araştırma ve analiz SaaS'ı.

**Temel farklılaşma:**
- Trendyol / Hepsiburada arbitraj tespiti (rakiplerde yok)
- Alibaba + DHgate + Türkiye tedarikçi entegrasyonu
- Türkçe arayüz ve Türk pazarına özel özellikler
- Unmet Demand tespiti + Product Opportunity Gap (rakiplerde yok)
- Love/Hate Claude AI yorum analizi
- Business Valuation Tool (ZonGuru'dan güçlü)
- SnapSearch — görsel ile ürün arama (Faz 2)
- WhatsApp / Telegram fiyat alertleri (Faz 2)
- Mobil uygulama (Faz 3)
- Barkod okuyucu (Faz 3)

---

## 2. Hedef Kitle

- Türkiye'den Amazon'da satış yapan veya yapmak isteyen bireysel satıcılar
- Trendyol satıcıları → Amazon'a geçmek isteyenler
- Amazon FBA başlangıç seviyesi satıcılar (global)
- Küçük e-ticaret ajansları
- Avrupa'daki Türk diasporası (Amazon.de, Amazon.fr)

---

## 3. Rakip Analizi

| Özellik | Helium 10 | Jungle Scout | AMZScout | SmartScout | AmazenLens |
|---------|-----------|--------------|----------|------------|------------|
| Fiyat | $97+/ay | $49+/ay | $45+/ay | $65+/ay | $19+/ay |
| Türkçe | ❌ | ❌ | ❌ | ❌ | ✅ |
| Trendyol arbitraj | ❌ | ❌ | ❌ | ❌ | ✅ |
| Global Arbitraj | ❌ | ❌ | ❌ | ❌ | ✅ |
| 4 Boyutlu Niş Skoru | ❌ | ❌ | ❌ | ❌ | ✅ |
| Unmet Demand | ❌ | ❌ | ❌ | ❌ | ✅ |
| Love/Hate AI | Zayıf | Zayıf | Zayıf | ❌ | ✅ Claude |
| Product Opp. Gap | ❌ | ❌ | ❌ | ❌ | ✅ (Faz 2) |
| Business Valuation | ❌ | ❌ | ❌ | Zayıf | ✅ (Faz 2) |
| Türk Tedarikçi DB | ❌ | ❌ | ❌ | ❌ | ✅ (Faz 3) |
| Barkod okuyucu | ❌ | Zayıf | ❌ | ❌ | ✅ (Faz 3) |
| Mobil app | ❌ | ❌ | ❌ | ❌ | ✅ (Faz 3) |
| WhatsApp alert | ❌ | ❌ | ❌ | ❌ | ✅ (Faz 2) |

---

## 4. Özellik Listesi — Fazlara Göre

### ✅ Faz 1 — TAMAMLANANLAR

| # | Özellik | Durum | Notlar |
|---|---------|-------|--------|
| 1 | Kullanıcı kaydı/girişi | ✅ | Supabase Auth |
| 2 | Keyword araması + ürün görselleri | ✅ | Mock modda (Easyparser kredi doldu) |
| 3 | Ürün detayı + platform linkleri | ✅ | Varyantlar, FBA/FBM, satıcı sayısı eklendi |
| 4 | Unavailable Scanner | ✅ | 3 sekme: ASIN / Keyword / Kategori |
| 5 | Niş Skoru (100pt) + AI yorum | ✅ | Unmet Demand + Red Flags + 3 Prong |
| 6 | Alibaba Tedarikçi Finder | ✅ | Mock data |
| 7 | Global Arbitraj (Trendyol/eBay) | ✅ | Mock data |
| 8 | Toplu ASIN Import (100 ASIN) | ✅ | CSV/Excel |
| 9 | Blog Sistemi | ✅ | Admin panel + Supabase |
| 10 | Love/Hate Yorum Analizi | ✅ | Claude API, 4 dil (TR/EN/DE/FR) |
| 11 | Keywords on Fire (Est. Revenue) | ✅ | Aylık tahmini gelir kolonu |
| 12 | Cache sistemi | ✅ | 1 saat TTL, kredi tasarrufu |
| 13 | Yeni UI Tasarımı | ✅ | Inter font, koyu sidebar, Apple tarzı |
| 14 | FBA/FBM + Satıcı sayısı | ✅ | Arama listesinde ve ürün detayında |

### ❌ Faz 1 — BEKLEYENLER

| # | Özellik | Not |
|---|---------|-----|
| 15 | Stripe Ödeme + Pricing sayfası | Sıradaki büyük adım |
| 16 | Keepa API | $20/ay — BSR+FBA+satıcı gerçek veri |
| 17 | 4 Dil Desteği (i18next) | Altyapı hazır |
| 18 | Quick Picks / Günün Fırsatları | Dashboard widget |
| 19 | NichePage yeni tasarım | — |
| 20 | SourcingPage yeni tasarım | — |
| 21 | AuthPage yeni tasarım | — |
| 22 | BulkPage yeni tasarım | — |
| 23 | Canlıya çık (Vercel + Railway) | Stripe sonrası |

---

### 🟡 Faz 2 — ARAŞTIRMA PLATFORMU

| # | Özellik | Kaynak İlham | Öncelik |
|---|---------|--------------|---------|
| 1 | Product Opportunity Gap | Amazon POE + Niş Skoru | 🔴 Yüksek — Rakipsiz |
| 2 | Business Valuation Tool | ZonGuru (zayıf var) | 🔴 Yüksek |
| 3 | Sezonluk Talep + Stok Önerisi | Rakiplerde yok! | 🔴 Yüksek |
| 4 | Euro Flips | FBA Wizard Pro | 🟡 Orta |
| 5 | Chrome & Edge Eklentisi | Jungle Scout | 🔴 Yüksek |
| 6 | AI Listing Optimizer | Helium 10 | 🟡 Orta |
| 7 | Review Analyzer — Gelişmiş | Keyword bazlı, rakiplerde yok | 🟡 Orta |
| 8 | Keyword Explorer | Helium 10 Cerebro | 🟡 Orta |
| 9 | Reverse ASIN | Helium 10 | 🟡 Orta |
| 10 | Always Be Scanning | Tactical Arbitrage | 🟡 Orta |
| 11 | Wholesale Manifest Upload | Tactical Arbitrage | 🟡 Orta |
| 12 | WhatsApp / Telegram Alertleri | — | 🟡 Orta |
| 13 | Sales Estimator | Jungle Scout | 🟡 Orta |
| 14 | FBA Kar Hesaplayıcı (gelişmiş) | — | 🟡 Orta |
| 15 | SnapSearch (görsel arama) | Google Lens | 🟡 Orta |
| 16 | Hepsiburada arbitraj | — | 🟡 Orta |
| 17 | Çok Kaynaklı Tedarikçi Karşılaştırma | Alibaba+DHgate+TR+KR | 🔴 Yüksek |
| 18 | Kore Tedarikçileri (tradeKorea, EC21) | — | 🟢 Düşük |
| 19 | Global Sources, 1688.com | — | 🟢 Düşük |
| 20 | Vergi Araçları Modülü (VAT, Sales Tax, Gümrük) | — | 🟡 Orta |
| 21 | Listing Quality Score | AMZScout | 🟢 Düşük |
| 22 | Stock Stats (rakip stok takibi) | AMZScout | 🟢 Düşük |
| 23 | AdSpy (rakip PPC) | SmartScout | 🟢 Düşük |
| 24 | PDF/Sheets export | — | 🟢 Düşük |
| 25 | IP Alert | Helium 10 | 🟢 Düşük |

---

### 🟠 Faz 3 — MOBİL & GELİŞMİŞ

| # | Özellik |
|---|---------|
| 1 | iOS + Android App (React Native) |
| 2 | Barkod Okuyucu (mağazada anında analiz) |
| 3 | Seller Map (coğrafi satıcı haritası) |
| 4 | 1688 + Made-in-China + DHgate entegrasyonu |
| 5 | Türk Tedarikçi Veritabanı (KobiVadisi, Bilvio, Kolay İhracat) |
| 6 | Pan-European FBA rehberi |
| 7 | ABD Tedarikçi (ThomasNet) |
| 8 | Avrupa Tedarikçi (Europages) |
| 9 | Japonya pazarı özellikleri (Amazon.co.jp) |
| 10 | Kore pazarı özellikleri |
| 11 | UAE / Suudi Arabistan pazarı |
| 12 | Meksika pazarı |
| 13 | Merch/POD modu |

---

### 🔵 Faz 4 — ENTERPRİSE

| # | Özellik |
|---|---------|
| 1 | Intelligence API (Fal.ai modeli) |
| 2 | ML Model Eğitimi |
| 3 | EtsyLens |
| 4 | Amazon Appstore başvurusu |
| 5 | Sesli Asistan |
| 6 | White-label B2B |
| 7 | Patent Risk Tarayıcı |
| 8 | SWOT Analizi (AI) |
| 9 | QuickBooks / Muhasebe Entegrasyonu |
| 10 | Brezilya, Rusya, Güney Afrika pazarları |

---

## 5. Niş Skor Sistemi (100 Puan)

```
Niş Skoru = Hacim & Depolama (25) + Lojistik (25) + Rekabet (25) + Karlılık (25)
```

### 5.1 Hacim & Depolama (25 puan)

| Kriter | Puan |
|--------|------|
| Ürün ağırlığı (≤0.5 lb = 25, ≤1 lb = 20...) | 0–25 |
| BSR bazlı depolama riski (<1000 BSR = +5) | 0–5 |

### 5.2 Lojistik (25 puan)

| Kriter | Puan |
|--------|------|
| Ağırlık (< 1 lb = 10 puan) | 0–10 |
| FBA uygunluğu | 0–5 |
| Kırılgan değilse +5 | 0–5 |
| Alibaba'da mevcut | 0–5 |

### 5.3 Rekabet (25 puan)

| Kriter | Puan |
|--------|------|
| Rakip sayısı / review sayısı (<100 = 7) | 0–7 |
| Orta rekabet varsayılan | 0–8 |
| Büyük marka yok (+5) | 0–5 |
| Patent riski yok (+5) | 0–5 |

### 5.4 Karlılık (25 puan)

| Kriter | Puan |
|--------|------|
| Satış fiyatı ($15–50 ideal = 8) | 0–8 |
| Tahmini kar marjı (>%50 = 10) | 0–10 |
| Fiyat rekabeti (savaş yoksa +7) | 0–7 |

### Red Flags (Puan düşmez, uyarı gösterilir)

| Flag | Tetikleyici |
|------|-------------|
| 🚩 Big Brand | Nike, Apple, Amazon, Samsung vb. |
| 🚩 Seasonal | Christmas, Halloween, Summer vb. |
| 🚩 Low Development | basic, simple, generic + review>5000 + rating>4.5 |
| 🚩 Patent Risk | ®, ™, patent geçiyor |
| 🚩 Fragile | Glass, ceramic, mirror, crystal |
| 🚩 Heavy | >10 lb |

### Unmet Demand Sinyalleri

| Sinyal | Koşul | Ağırlık |
|--------|-------|---------|
| Az rakip, yüksek talep | review<200 + BSR<10000 | +40 |
| Düşük memnuniyet, yüksek satış | rating<4.0 + BSR<20000 | +35 |
| Premium segment boş | price>40 + review<500 | +25 |
| Yükselen trend | BSR<5000 + review<100 | +50 |

### 3 Prong Testi (Dan Rodgers)

- ✅ Yüksek Fiyat: ≥$25
- ✅ Geliştirme Potansiyeli: low_dev değil + review<1000
- ✅ Az Review OK: review<500

### Skor Değerlendirmesi

| Skor | Karar |
|------|-------|
| 90–100 | 🟢 Mükemmel — Hemen gir |
| 70–89 | 🟡 İyi — Araştır |
| 50–69 | 🟠 Orta — Dikkatli ol |
| 0–49 | 🔴 Zayıf — Kaçın |

---

## 6. Tedarikçi Platform Ekosistemi

### 6.1 Türkiye Tedarikçi Platformları (Rakiplerde Yok)

| Platform | Ne Yapar | Faz |
|----------|----------|-----|
| KobiVadisi | Türk üretici/tedarikçi dizini | Faz 3 |
| Kolay İhracat | T.C. Ticaret Bakanlığı resmi platformu | Faz 3 |
| Bilvio.com | GTİP kodu bazında ihracatçı veritabanı | Faz 3 |
| İhracatçılar Birliği | Sektörel ihracatçı listeleri | Faz 3 |

**"Made in Turkey" Avantajı:** Tekstil, deri, ev tekstilinde premium fiyat + AB'de güçlü marka algısı + Gümrük Birliği sıfır gümrük avantajı.

### 6.2 Çin Tedarikçi Platformları

| Platform | Güçlü Alan | Faz |
|----------|-----------|-----|
| Alibaba | Genel, geniş seçenek | Faz 1 ✅ |
| DHgate | Düşük MOQ, dropshipping | Faz 1 ✅ |
| Global Sources | Doğrulanmış fabrikalar | Faz 2 |
| 1688.com | En ucuz Çin fiyatları | Faz 2 |
| Made in China | Fabrika doğrulama, OEM/ODM | Faz 2 |

### 6.3 Kore Tedarikçi Platformları

| Platform | Güçlü Alan | Faz |
|----------|-----------|-----|
| tradeKorea | Premium Kore ürünleri | Faz 2 |
| EC21 | Geniş Kore tedarikçi ağı | Faz 2 |

### 6.4 Çok Kaynaklı Karşılaştırma (Faz 2)

```
Kullanıcı "yoga mat" arar → AmazenLens TÜM platformlarda arar:
├── Alibaba        → $3.50/adet, MOQ: 500
├── DHgate         → $3.80/adet, MOQ: 50
├── Global Sources → $4.20/adet, doğrulanmış fabrika
├── Türkiye        → ₺150/adet ($5), 2 gün teslimat
├── tradeKorea     → $6.00/adet, premium kalite
└── 1688.com       → $2.90/adet (en ucuz)
→ Yan yana kar marjı karşılaştırması
```

---

## 7. Marketplace Özel Özellikler

### 🇹🇷 Türkiye
- Trendyol / Hepsiburada arbitraj
- Türkçe AI asistan
- Türk tedarikçi modülü
- KOSGEB/TÜBİTAK e-ihracat desteği bilgilendirmesi

### 🇩🇪 Almanya / AB
- Pan-EU FBA kar hesabı (5 ülke VAT dahil)
- AB ViDA (e-fatura) uyumluluk uyarısı
- Çevre vergisi / ambalaj vergisi uyarısı
- Almanca keyword araması

### 🇬🇧 İngiltere
- Brexit sonrası UK ↔ AB rehberi
- HMRC VAT hesabı (%20)
- UK → AB Remote Fulfillment

### 🇦🇪 UAE / 🇸🇦 Suudi
- AED / SAR fiyat gösterimi
- Halal ürün filtresi
- Amazon.ae + Amazon.sa desteği

---

## 8. Vergi Araçları Modülü (Faz 2)

### VAT Oranları

| Marketplace | VAT |
|-------------|-----|
| Amazon.de | %19 |
| Amazon.fr | %20 |
| Amazon.it | %22 |
| Amazon.co.uk | %20 |
| Amazon.ae | %5 |
| Amazon.co.jp | %10 |
| Amazon.com | Eyalet bazlı |

### Planlanan Araçlar

1. **Gerçek Zamanlı VAT Kar Hesabı** — ülke seçince otomatik VAT uygular
2. **Pan-EU VAT Uyumluluk Checker** — OSS eşiği, kayıt gereklilikleri
3. **ABD Sales Tax** — eyalet bazlı, Nexus tespiti
4. **Gümrük Hesabı** — Türkiye → AB/ABD gönderimde maliyet
5. **Made in Turkey Avantajı** — Gümrük Birliği sıfır gümrük kategorileri

---

## 9. Global Pazar Haritası

| Pazar | Faz | Dil | Not |
|-------|-----|-----|-----|
| 🇹🇷 Türkiye | 1 | TR | Ana pazar |
| 🇺🇸 ABD | 1 | EN | En büyük |
| 🇩🇪 Almanya | 1 | DE | — |
| 🇫🇷 Fransa | 1 | FR | — |
| 🇦🇪 UAE + 🇸🇦 KSA | 1 | EN | Düşük VAT avantajı |
| 🇸🇪 İsveç + Nordikler | 1 | EN | 4 ülke tek depo |
| 🇬🇧 İngiltere | 2 | EN | Brexit karmaşık |
| 🇯🇵 Japonya | 2 | JA | Dev fırsat |
| 🇰🇷 Kore | 2 | KO | K-beauty güçlü |
| 🇲🇽 Meksika | 2 | ES | Düşük rekabet |
| 🇧🇷 Brezilya | 3 | PT | Vergi zorlu |
| 🇿🇦 Güney Afrika | 3 | EN | Büyüyor |
| 🇨🇳 Çin | 4+ | ZH | Ayrı altyapı |

---

## 10. Blog Sistemi

### Supabase Tablosu: blog_posts

```sql
id, title_tr, title_en, slug, summary_tr, summary_en,
content_tr, content_en, cover_image, category, tags[],
author, published, featured, read_time, view_count,
created_at, updated_at
```

### Planlanan İlk 10 Makale

1. ✅ Amazon FBA Nedir? Türkiye'den Nasıl Başlanır?
2. Trendyol'dan Amazon'a Arbitraj: 2026 Tam Rehberi
3. Alibaba'dan Güvenli Ürün Alma Rehberi
4. Amazon'da Karlı Ürün Nasıl Bulunur?
5. Helium 10 vs AmazenLens Karşılaştırma
6. BSR Nedir? Nasıl Yorumlanır?
7. Amazon'da İlk $1000: Gerçek Hikaye
8. FBA Masrafları: Gerçek Karlılık Hesabı
9. ABD'de Vergi: Türk Girişimci Ne Yapmalı?
10. Amazon Niş Skoru Nedir?

---

## 11. Veri Modeli (Supabase)

```sql
profiles         — id, email, plan, api_calls_this_month
search_history   — id, user_id, query, results
tracked_products — id, user_id, asin, alert_price
feature_requests — id, user_id, feature, votes
blog_posts       — id, title_tr/en, slug, content, published
```

---

## 12. API Endpoint'leri

```
GET  /api/amazon/search?q={keyword}
GET  /api/amazon/product/{asin}
POST /api/amazon/unavailable-scanner
GET  /api/amazon/niche-score/{asin}

GET  /api/sourcing/alibaba?keyword={q}
GET  /api/sourcing/arbitrage?keyword={q}&amazon_price={p}
GET  /api/sourcing/profit-calc?amazon_price={p}&alibaba_price={a}

GET  /api/reviews/analyze/{asin}?title={t}&lang={l}

POST /api/bulk/upload
POST /api/bulk/process

POST /api/auth/register
POST /api/auth/login
GET  /api/auth/me

GET  /api/blog/posts
GET  /api/blog/posts/{slug}
POST /api/blog/posts
PUT  /api/blog/posts/{slug}
DELETE /api/blog/posts/{slug}
```

---

## 13. Deployment Planı

| Servis | Platform | Maliyet | Durum |
|--------|----------|---------|-------|
| Frontend | Vercel | Ücretsiz | ❌ Henüz yok |
| Backend | Railway | ~$5/ay | ❌ Henüz yok |
| Veritabanı | Supabase | Ücretsiz | ✅ Aktif |
| Domain | Namecheap | ~$12/yıl | ❌ Henüz yok |

**Tahmini aylık API maliyeti (canlıda):**
- Easyparser: $49/ay (ya da Canopy alternatifi)
- Keepa: $20/ay
- Railway: $5/ay
- Toplam: ~$74/ay
- Breakeven: 4 Starter müşteri ($19×4 = $76)

---

## 14. Değişiklik Geçmişi

| Tarih | Değişiklik |
|-------|------------|
| Mart 2025 | İlk versiyon |
| Mart 2026 | Faz 1 büyük ölçüde tamamlandı |
| Mart 2026 | Easyparser API (Rainforest yerine) |
| Mart 2026 | Blog sistemi eklendi |
| Mart 2026 | Toplu ASIN Import eklendi |
| Mart 2026 | Love/Hate yorum analizi (Claude API) |
| Mart 2026 | Unmet Demand + Red Flags + 3 Prong eklendi |
| Mart 2026 | Keywords on Fire (Est. Revenue) eklendi |
| Mart 2026 | FBA/FBM + Satıcı sayısı eklendi |
| Mart 2026 | Varyant desteği eklendi |
| Mart 2026 | Yeni UI tasarımı (Inter font, koyu sidebar) |
| Mart 2026 | Cache sistemi eklendi |
| Mart 2026 | Türkiye tedarikçi platformları eklendi |
| Mart 2026 | Vergi araçları modülü planlandı |
| Mart 2026 | Global pazar haritası genişletildi (15 pazar) |
| Mart 2026 | Kore tedarikçi platformları eklendi |
| Mart 2026 | Çok kaynaklı tedarikçi karşılaştırma planlandı |
