# AmazenLens — Güçlendirme Araştırması

**Tarih:** Mart 2026  
**Kaynak:** Rakip analizi + pazar araştırması

---

## 📊 Öncelik Matrisi

| # | Özellik | Faz | Zorluk | Etki | Durum |
|---|---------|-----|--------|------|-------|
| 1 | Love/Hate Kelime Bulutu | 1 | Kolay | 🔴 Yüksek | ✅ TAMAMLANDI |
| 2 | Keywords on Fire (Est. Revenue) | 1 | Orta | 🔴 Yüksek | ✅ TAMAMLANDI |
| 3 | Unmet Demand Tespiti | 1 | Orta | 🔴 Yüksek | ✅ TAMAMLANDI |
| 4 | Red Flags + 3 Prong Testi | 1 | Kolay | 🔴 Yüksek | ✅ TAMAMLANDI |
| 5 | FBA/FBM + Satıcı Sayısı | 1 | Kolay | 🔴 Yüksek | ✅ TAMAMLANDI |
| 6 | Varyant Desteği | 1 | Orta | 🟡 Orta | ✅ TAMAMLANDI |
| 7 | Euro Flips | 1 | Kolay | 🟡 Orta | ⏳ Bekliyor |
| 8 | Product Opportunity Gap | 2 | Orta | 🔴 Yüksek | ⏳ Planlandı |
| 9 | Business Valuation Tool | 2 | Orta | 🔴 Yüksek | ⏳ Planlandı |
| 10 | Sezonluk Talep + Stok Önerisi | 2 | Zor | 🔴 Yüksek | ⏳ Planlandı |
| 11 | Çok Kaynaklı Tedarikçi Karşılaştırma | 2 | Orta | 🔴 Yüksek | ⏳ Planlandı |
| 12 | Review Analyzer Gelişmiş | 2 | Orta | 🟡 Orta | ⏳ Planlandı |
| 13 | Vergi Araçları Modülü | 2 | Orta | 🟡 Orta | ⏳ Planlandı |
| 14 | Listing Optimizer + Rakip Karşılaştırma | 2 | Kolay | 🟡 Orta | ⏳ Planlandı |
| 15 | Sales Estimator Çoklu Kaynak | 2 | Orta | 🟡 Orta | ⏳ Planlandı |

---

## ✅ TAMAMLANANLAR

### 1. Love/Hate Kelime Bulutu
ZonGuru'nun Love/Hate aracı ürün yorumlarını tarayarak müşterilerin ne sevdiğini ve nefret ettiğini iki sütunda gösteriyor.

**Bizim versiyonumuz:** Claude API ile gerçek zamanlı analiz, 4 dil desteği (TR/EN/DE/FR), örnek yorumlar, memnuniyet skoru, ürün geliştirme fırsatı kutusu. ProductPage'de "💚❤️ Yorumlar" sekmesi.

---

### 2. Keywords on Fire (Est. Revenue)
ZonGuru'nun en sevilen özelliği. Aylık tahmini gelir gösterimi.

**Bizim versiyonumuz:** SearchPage'de Est. Revenue kolonu ($10K sarı, $50K+ yeşil). Toplam pazar büyüklüğü göstergesi. Gelire göre varsayılan sıralama.

---

### 3. Unmet Demand Tespiti
Amazon'un kendi AI'ı müşterilerin aradığı ama bulamadığı ürünleri tespit ediyor.

**Bizim versiyonumuz:** 4 sinyal (az review+iyi BSR, düşük rating+yüksek satış, premium boş, yeni trend). Niş Skoru sekmesinde "🔥 Karşılanmamış Talep" bölümü.

---

### 4. Red Flags + 3 Prong Testi
Dan Rodgers metodolojisi.

**Bizim versiyonumuz:** 6 red flag (Big Brand, Seasonal, Low Dev, Patent Risk, Fragile, Heavy). 3 Prong testi: Yüksek Fiyat + Geliştirilebilir + Az Review.

---

### 5. FBA/FBM + Satıcı Sayısı
Arama listesinde ve ürün detay sayfasında gösteriliyor.

**Bizim versiyonumuz:** Arama listesinde FBA/FBM rozeti + satıcı sayısı. "Sadece FBA" filtresi. "Max Satıcı" filtresi. Ürün detayında badge'ler.

---

### 6. Varyant Desteği
Ürün detay sayfasında tıklanabilir varyant chip'leri.

**Bizim versiyonumuz:** Header'da tıklanabilir chip'ler, varyant tipini gösterir (Renk/Beden vb.), tıklayınca o varyantın sayfasına gider.

---

## ⏳ SIRADAKILER

### 7. Euro Flips (Faz 1 — Kolay — 🟡 Orta)
FBA Wizard Pro, Amazon UK ve Avrupa pazarları arasındaki arbitraj fırsatlarını tespit ediyor.

**Bizim planımız:** Mevcut arbitraj modülüne Amazon.de, Amazon.fr, Amazon.co.uk fiyat karşılaştırması ekle. Altyapı hazır, sadece pazarlar arası kar hesabı eklenecek.

---

### 8. Product Opportunity Gap (Faz 2 — Orta — 🔴 Yüksek — RAKİPSİZ!)
Amazon'un Product Opportunity Explorer aracı ücretsiz ama eksik: gelişmiş filtre yok, tarihsel veri yok, niş skoru yok, Alibaba bağlantısı yok.

**Bizim farkımız:** Amazon POE verilerini alıp üstüne şunları ekleriz:
- Niş Skoru otomatik hesaplanır
- Alibaba'da tedarikçi fiyatı gösterilir
- Kar marjı hesaplanır
- "Bu fırsatı yakala" butonu

**Sonuç:** Hiçbir rakipte bu entegrasyon yok. Bu özellik tek başına abonelik nedeni olabilir.

---

### 9. Business Valuation Tool (Faz 2 — Orta — 🔴 Yüksek)
Sadece ZonGuru'da var, ama zayıf versiyonu. Türk satıcılar için devrimsel.

**Formül:** Aylık net kar × 36-48x çarpan = işletme değeri

**Bizim versiyonumuz:**
- Kullanıcı ürünlerini, satış hızını, kar marjını girer
- "Bu Amazon işi bugün $X'e satılabilir" hesabı
- Büyüme senaryoları (optimist/kötümser)
- "İşimi nasıl daha değerli yaparım?" önerileri

---

### 10. Sezonluk Talep Tahmini + Stok Önerisi (Faz 2 — Zor — 🔴 Yüksek — RAKİPSİZ!)
Hiçbir rakip araçta yok. Prediktif analitik + stok siparişi birleşimi.

**Özellik:** "Bu ürünün Q4'te satışı 3x artacak, şimdi 500 adet sipariş ver"

**Yapılacak:**
- Keepa API'den tarihsel BSR/fiyat verisi
- Google Trends entegrasyonu
- Sezonluk tahmin modeli (kural tabanlı + Claude AI yorum)
- "Ne zaman, kaç adet sipariş ver" önerisi

---

### 11. Çok Kaynaklı Tedarikçi Karşılaştırma (Faz 2 — Orta — 🔴 Yüksek)
Rakiplerde tek platform (sadece Alibaba) var. Bizim yan yana karşılaştırma özelliğimiz rakipsiz.

**Platformlar:** Alibaba + DHgate + Global Sources + 1688.com + Türkiye (KobiVadisi) + Kore (tradeKorea)

**Görünüm:**
```
Platform      | Fiyat        | MOQ | Teslimat | Güven  | Kar Marjı
Alibaba       | $3.50/adet   | 500 | 25 gün   | ⭐⭐⭐⭐⭐ | %68
DHgate        | $3.80/adet   |  50 | 20 gün   | ⭐⭐⭐⭐  | %65
Türkiye       | $5.00/adet   |   1 |  2 gün   | ⭐⭐⭐⭐⭐ | %58
1688.com      | $2.90/adet   | 200 | 30 gün   | ⭐⭐⭐   | %71 ← En karlı
```

---

### 12. Review Analyzer — Gelişmiş (Faz 2 — Orta — 🟡 Orta)
Mevcut Love/Hate analizini keyword bazlı hale getir.

**Yeni özellik:** "yoga mat" keyword'ündeki TÜM ürünlerin yorumlarından ortak şikayet ve övgüleri çıkar → ürün geliştirme fırsatı. Rakiplerde yok!

**Ek:** İnteraktif kelime bulutu — tıklayınca o kelimeyle ilgili yorumlar açılır.

---

### 13. Vergi Araçları Modülü (Faz 2 — Orta — 🟡 Orta)

**Araçlar:**
1. Gerçek zamanlı VAT kar hesabı (ülke seçince otomatik)
2. Pan-EU VAT uyumluluk checker (OSS eşiği)
3. ABD Sales Tax (eyalet bazlı, Nexus tespiti)
4. Gümrük hesabı (Türkiye → AB/ABD)
5. Made in Turkey vergi avantajı (Gümrük Birliği)

**VAT Oranları:** DE %19, FR %20, IT %22, UK %20, UAE %5, JP %10

---

### 14. Listing Optimizer + Rakip Karşılaştırma (Faz 2 — Kolay — 🟡 Orta)
Jungle Scout zayıflığı: rakip listing gücünü göstermiyor, CSV export yok.

**Bizim versiyonumuz:**
- Kendi listing'ini gir + rakip ASIN gir
- Yan yana keyword karşılaştırma
- Listing Quality Score (0-100)
- CSV export

---

### 15. Sales Estimator — Çoklu Kaynak (Faz 2 — Orta — 🟡 Orta)
Helium 10 %71 doğruluk oranıyla öne çıkıyor. Biz Easyparser + Keepa + kendi algoritmamızı birleştirerek daha doğru tahmin üretebiliriz.

---

## 🗒️ Notlar & Kararlar

- **Türkçe Topluluk + Canlı Q&A:** İPTAL edildi
- **Product Opportunity Gap:** En stratejik özellik — Amazon'un kendi verisini güçlendirip sunmak hiçbir rakipte yok
- **Business Valuation:** Türk satıcılar için özellikle değerli
- **Sezonluk Stok:** Keepa API gerekli, alındıktan sonra yapılacak
- **Çok Kaynaklı Tedarikçi:** Faz 2'nin en güçlü differentiator'ı
- **Vergi Araçları:** Avrupa pazarına giriş için kritik, rakiplerde yok

## 🔗 API İhtiyaçları

| Özellik | API Gereksinim | Maliyet |
|---------|---------------|---------|
| Sezonluk talep | Keepa API | $20/ay |
| Sezonluk trend | Google Trends API | Ücretsiz |
| VAT doğrulama | VIES API (AB) | Ücretsiz |
| ABD Sales Tax | TaxJar | $19/ay |
| Tedarikçi | Alibaba resmi API | Başvuru gerekli |
